# S_LEM Design - Jewelry OEM Website

## 概要
S_LEM DesignのジュエリーOEMサービスのランディングページです。

## ファイル構成
```
/
├── index.html              # メインページ
├── privacy-policy.html     # プライバシーポリシー
├── terms-of-service.html   # 利用規約
├── robots.txt              # SEO用
├── sitemap.xml             # SEO用
├── favicon.svg             # ファビコン
├── logo.png                # ヘッダーロゴ
├── header-image.png        # デスクトップヘッダー画像
├── mobile-header.png       # モバイルヘッダー画像
├── sozai.png               # Salemセクション画像
├── gazou.png               # Salemセクション画像
├── scroll-icon.png         # スクロールアイコン
├── instagram-icon.png      # Instagramアイコン
└── archive-images/         # アーカイブ画像（7枚）
    ├── IMG_2656.jpeg
    ├── 3Q0A7278（大）.jpeg
    ├── DSC07029（大）.jpeg
    ├── DSC06486（大）.jpeg
    ├── DSC05645（大）.jpeg
    ├── DSC00839（大）.jpeg
    └── DSC07066（大）.jpeg
```

## セクション構成
1. **ヘッダー**: ロゴ、ナビゲーション、Instagramリンク
2. **トップページ**: フルスクリーンヘッダー画像、スクロールアイコン
3. **Salemセクション**: 2分割レイアウト（左: sozai.png、右: gazou.png）
4. **Archiveセクション**: 7枚の画像を横スクロール表示
5. **About Usセクション**: OEMサービス紹介、4枚の画像グリッド
6. **Contactセクション**: 問い合わせフォーム
7. **フッター**: 連絡先情報、リンク

## レスポンシブ対応
- **デスクトップ**: 1200px以上
- **タブレット**: 768px-1199px
- **モバイル**: 767px以下

## デプロイメント

### Netlify（推奨）
1. **ZIPファイル準備済み**: `s-lem-design-website.zip` (992KB)
2. [Netlify](https://netlify.com)にアクセス
3. 「Deploy manually」をクリック
4. `s-lem-design-website.zip`をドラッグ&ドロップ
5. 自動デプロイ完了（約1分）

**デプロイ後の設定:**
- サイト名の変更（例: `s-lem-design`）
- カスタムドメインの設定（オプション）
- HTTPS証明書は自動で設定される

#### Vercel
1. GitHubリポジトリにプッシュ
2. [Vercel](https://vercel.com)でプロジェクト作成
3. 自動デプロイ完了

#### GitHub Pages
1. GitHubリポジトリ作成
2. ファイルをプッシュ
3. Settings > Pages で有効化

### 従来のWebサーバー
Apache/Nginxサーバーにファイルをアップロード：
```
/public_html/
├── index.html
├── privacy-policy.html
├── terms-of-service.html
├── robots.txt
├── sitemap.xml
├── favicon.svg
├── logo.png
├── header-image.png
├── mobile-header.png
├── sozai.png
├── gazou.png
├── scroll-icon.png
├── instagram-icon.png
└── archive-images/
    └── (7枚の画像)
```

## 技術仕様
- **HTML5**: セマンティックマークアップ
- **CSS3**: Flexbox、Grid、レスポンシブデザイン
- **JavaScript**: スムーススクロール、フォーム処理
- **Google Fonts**: Oswaldフォント
- **画像形式**: PNG、JPEG

## 連絡先
- **Email**: salem.jewellers.jp@gmail.com
- **Instagram**: https://www.instagram.com/s_lem_design/
- **住所**: 107 Chiharu Bldg. Jingumae Shibuya-ku Tokyo-to
- **営業時間**: 12:00~20:00

## 更新履歴
- 2025/10/05: 公開用に最適化、不要ファイル削除
- アーカイブ画像をJPEG形式に統一
- About Usセクションを2×2グリッドレイアウトに修正